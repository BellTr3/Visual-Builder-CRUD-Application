define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateEmployeeChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const navigateToPageEmpCreateEmployeeResult = await Actions.navigateToPage(context, {
        page: 'emp-create-employee',
        params: {},
      });
    }
  }

  return navigateToCreateEmployeeChain;
});
